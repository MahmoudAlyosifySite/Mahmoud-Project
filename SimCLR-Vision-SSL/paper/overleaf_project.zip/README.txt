Where Do Scarce Labels Belong? A Compute-Matched Study of Supervised and Self-Supervised Contrastive Pretraining

arxiv.tex         preprint version (compact single column)            -> set as main document for the arXiv PDF
submission.tex    journal version for Neural Networks (review layout)  -> set as main document for the journal PDF
highlights.tex    Elsevier highlights file
cover_letter.tex  cover letter to the editor

Both versions share all text files (sec_*.tex, abstract.tex, appendix.tex, statements.tex). The numbers, tables
and figures in generated/ and figures/ are produced by scripts/make_assets.py in the code repository; edit the
text files, not generated/. Code: https://github.com/MahmoudAlyosifySite/Mahmoud-Project/tree/main/SimCLR-Vision-SSL
